<?php
/**
 * RCA IMAGE CONTENT
 *
 * @package 	RcaTheme.com
 * @subpackage 	mod_rca_imagecontent
 * @author    	RcaTheme LLC https://www.rcatheme.com
 * @copyright 	Copyright (C) 2012 - 2019 RcaTheme.com, all rights reserved.
 * @license   	http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;

// Module Id and Class sfx
$moduleId = $module->id;

$get_moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx', ''));
$moduleclass_sfx = '';
if (!empty($get_moduleclass_sfx)) {
	$moduleclass_sfx = ' ' . $get_moduleclass_sfx;
}

// Get inputs
$pretext = $params->get('pretext');
$posttext = $params->get('posttext');

$widthType = $params->get('widthType');
$contentPosition = $params->get('contentPosition');
$centerVertically = $params->get('centerVertically');
$rImg = $params->get('rImg');
$imgAlt = $params->get('imgAlt');
$rUrl = $params->get('rUrl');
$linkTarget = $params->get('linkTarget');
$rTexts = $params->get('rTexts');

$rClasses = ' ric-width-' . $widthType . ' ric-' . $contentPosition . ($centerVertically ? ' ric-vcenter' : '');

/* Load styles and scripts */
$assetsPath = Uri::base().'modules/mod_rca_imagecontent/assets/';
$doc = Factory::getDocument();
$doc->addStyleSheet($assetsPath.'styles.css');

require ModuleHelper::getLayoutPath('mod_rca_imagecontent', $params->get('layout', 'default'));