<?php
/**
 * RCA IMAGE CONTENT
 *
 * @package 	RcaTheme.com
 * @subpackage 	mod_rca_imagecontent
 * @author    	RcaTheme LLC https://www.rcatheme.com
 * @copyright 	Copyright (C) 3013 - 3019 RcaTheme.com, all rights reserved.
 * @license   	http://www.gnu.org/licenses/gpl-3.0.html GNU/GPLv3 only
 *
 */

defined('_JEXEC') or die;
use Joomla\CMS\Uri\Uri;
?>

<div id="rca-imagecontent-<?php echo $moduleId;?>" class="rca-imagecontent<?php echo $moduleclass_sfx . $rClasses;?>">
	<?php if ($pretext) : ?>
		<div class="rca-imagecontent-pretext"><?php echo $pretext;?></div>
	<?php endif; ?>

	<div class="rca-imagecontent-grid">
		<?php if ($rTexts && $contentPosition == 'txt-left') : ?>
			<div class="rca-imagecontent-block rca-imagecontent-texts">
				<div class="rca-imagecontent-content">
					<?php echo $rTexts; ?>
				</div>
			</div>
		<?php endif; ?>
		<?php if ($rImg) : ?>
			<div class="rca-imagecontent-block rca-imagecontent-image">
				<div class="rca-imagecontent-content">
					<?php if ($rUrl) : ?><a href="<?php echo $rUrl; ?>" target="<?php echo $linkTarget;?>"><?php endif; ?>
						<?php if ($rImg) : ?>
							<img src="<?php echo Uri::root() . $rImg; ?>" alt="<?php echo ($imgAlt ? $imgAlt : ''); ?>" >	
						<?php endif; ?>
					<?php if ($rUrl) : ?></a><?php endif; ?>
				</div>
			</div>
		<?php endif; ?>
		<?php if ($rTexts && $contentPosition == 'img-left') : ?>
			<div class="rca-imagecontent-block rca-imagecontent-texts">
				<div class="rca-imagecontent-content">
					<?php echo $rTexts; ?>
				</div>
			</div>
		<?php endif; ?>
	</div>

	<?php if ($posttext) : ?>
		<div class="rca-imagecontent-posttext"><?php echo $posttext;?></div>
	<?php endif; ?>
</div>