<?php
namespace Slideshowck;

defined('_JEXEC') or die;

jimport('joomla.filesystem.file');

class CKFile extends \JFile {
	
}
