<?php
namespace Slideshowck;

defined('_JEXEC') or die;

jimport('joomla.filesystem.folder');

class CKFolder extends \JFolder {
	
}
