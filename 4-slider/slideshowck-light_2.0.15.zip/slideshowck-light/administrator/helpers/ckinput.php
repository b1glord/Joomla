<?php
namespace Slideshowck;

defined('_JEXEC') or die;

class CKInput extends  \JInput {
	
}
