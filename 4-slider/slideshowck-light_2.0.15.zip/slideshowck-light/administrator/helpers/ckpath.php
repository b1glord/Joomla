<?php
namespace Slideshowck;

defined('_JEXEC') or die;

jimport('joomla.filesystem.file');

class CKPath extends \JPath {
	
}
