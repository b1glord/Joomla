<?php
namespace Slideshowck;

defined('_JEXEC') or die;

class CKText extends \JText {
	
}
