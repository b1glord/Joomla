<?php

 /**
 * @plugin Page Load Progress for Joomla! 3.X
 * @version $Id: PageLoadProgress.php 07/06/2017
 * @author Glimlag.gr
 * @copyright (C) 2017- Glimlag.gr
 * @license GNU/GPLv2 http://www.gnu.org/licenses/gpl-2.0.html
**/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Import library dependencies
jimport( 'joomla.plugin.plugin' );

class plgSystemPageLoadProgress extends JPlugin {
	
public function __construct( &$subject, $config )
{
parent::__construct( $subject, $config );

}

	function onBeforeRender() {

        $document = JFactory::getDocument();

        $barcolor = $this->params->get('barcolor');
        $pbarcolor = $barcolor;
        $prbarcolor = $barcolor;
        $textcolor = $this->params->get('textcolor');
        $opacity = $this->params->get('opacity');
        $template = $this->params->get('template');
        $document->addScript('plugins/system/PageLoadProgress/js/pace.min.js');
        $document->addStyleSheet('plugins/system/PageLoadProgress/templates/'.$template);


        if (strpos($template,"radar")!=false || strpos($template,"flash")!=false) $pbarcolor = 'none';
        if (strpos($template,"material")!=false || strpos($template,"big")!=false) $prbarcolor = 'none';
        $document->addScriptDeclaration(' Pace.on("start", function(){
            jQuery(".pace-activity").css("background","'.$pbarcolor.'");
            jQuery(".pace-activity").css("border-top-color","'.$barcolor.'");
            jQuery(".pace-activity").css("border-left-color","'.$barcolor.'"); 
            jQuery(".pace-activity").css("border-color","'.$barcolor.' transparent transparent");
            jQuery(".pace-progress").css("background","'.$prbarcolor.'");
            jQuery(".pace-progress").css("color","'.$textcolor.'");
            });
        ');
        $style = '.pace-running{
  opacity: '.$opacity.'
}';
        $document->addStyleDeclaration($style);
        return true;

	} // onBeforeRender

} // class

?>
