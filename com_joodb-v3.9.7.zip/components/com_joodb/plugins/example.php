<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

/**
 * Exmaple Plugin
 * 
 * VARIABLES
 * ===============
 * $output (String) = Parsed Template 
 * $item (object) = Current database entry
 * $joobase (object) = Current Joodatabe object
 * 
 */
 
// Never replace  $output. Append your output
$output .= "Hello World";

