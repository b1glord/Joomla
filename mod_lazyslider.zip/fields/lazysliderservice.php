<?php
/* Lazy Slider for Joomla 3.x - Version 1.0
--------------------------------------------------------------
 Copyright (C) 2017 AddonDev. All rights reserved.
 Website: https://addondev.com
 GitHub: https://github.com/philip-sorokin
 Developer: Philip Sorokin
 Location: Russia, Moscow
 E-mail: philip.sorokin@gmail.com
 Created: October 2017
 License: GNU GPLv2 http://www.gnu.org/licenses/gpl-2.0.html
--------------------------------------------------------------- */

defined('JPATH_PLATFORM') or die;

class JFormFieldLazysliderservice extends JFormField
{	
	protected $type = 'lazysliderservice';
	
	protected function getInput()
	{
		$doc = JFactory::getDocument();
		$app = JFactory::getApplication();
		
		$doc->addStyleDeclaration("
			.prospacer label, 
			.freespacer label {
				font-weight: bold;
				text-transform: uppercase;
				margin: 30px 0;
			}
			.freespacer label {
				margin-top: 10px;
			}
			.popover {
				max-width: 500px;
			}
			.imagesspacer label {
				margin-bottom: 20px;
				max-width: 1024px;
				cursor: auto;
			}
		");
		
		return '';
		
	}
	
	protected function getLabel()
	{
		return '';
	}
	
}