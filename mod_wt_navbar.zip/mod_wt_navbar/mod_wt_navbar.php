<?php
/**
 * @package     WT Navbar - Joomla Extension by WonderTheme.com
 *
 * @copyright   Copyright (C) 2019 WonderTheme.com. All rights reserved.
 * @license     GNU General Public License version 2 or later
 */

defined('_JEXEC') or die;

// Include the navbar functions only once
JLoader::register('Mod_WT_Navbar_Helper', __DIR__ . '/helper.php');

$doc 			        = JFactory::getDocument();
$list       			= Mod_WT_Navbar_Helper::getList($params);
$base       			= Mod_WT_Navbar_Helper::getBase($params);
$active     			= Mod_WT_Navbar_Helper::getActive($params);
$default    			= Mod_WT_Navbar_Helper::getDefault();
$active_id  			= $active->id;
$default_id 			= $default->id;
$path       			= $base->tree;
$showAll    			= $params->get('showAllChildren', 1);
$moduleclass_sfx  = htmlspecialchars($params->get('moduleclass_sfx'), ENT_COMPAT, 'UTF-8');
$baseURL   				= JUri::base(true);
$siteName 				= htmlspecialchars($app->get('sitename'), ENT_QUOTES, 'UTF-8');

// Get modules
jimport( 'joomla.application.module.helper' );
$modules = JModuleHelper::getModules('navbar-mod');

// Params
$logo 				 				= htmlentities($params->get('logo',''), ENT_COMPAT, 'UTF-8');
$navPlacement  				= htmlspecialchars($params->get('navPlacement', 'no-fixed'), ENT_COMPAT, 'UTF-8');
$navContainer     	  = htmlspecialchars($params->get('navContainer', 1), ENT_COMPAT, 'UTF-8');
$navPosition   				= htmlspecialchars($params->get('navPosition', 'mr-auto'), ENT_COMPAT, 'UTF-8');
$navBGColor			 	  	= htmlspecialchars($params->get('navBGColor', 'bg-light'), ENT_COMPAT, 'UTF-8');
$navColorMode 				= htmlspecialchars($params->get('navColorMode', 'navbar-light'), ENT_COMPAT, 'UTF-8');
$navBGColorCustom		  = htmlspecialchars($params->get('navBGColorCustom', '#0000ff'), ENT_COMPAT, 'UTF-8');
$navShadow		 				= htmlspecialchars($params->get('navShadow', 'shadow-none'), ENT_COMPAT, 'UTF-8');
$dropdownMode  		    = htmlspecialchars($params->get('dropdownMode', 'dropdown-open-click'), ENT_COMPAT, 'UTF-8');
$dropdownTransition		= htmlspecialchars($params->get('dropdownTransition', 'dropdown-transition-default'), ENT_COMPAT, 'UTF-8');
$navCollapse  				= htmlspecialchars($params->get('navCollapse', 'navbar-expand-lg'), ENT_COMPAT, 'UTF-8');
$loadOtherModules			= htmlspecialchars($params->get('loadOtherModules', 1), ENT_COMPAT, 'UTF-8');

// Load CSS/JS
JHtml::_('jquery.framework');
JHtml::_('stylesheet', 'modules/mod_wt_navbar/css/style.css', array('version' => 'auto', 'relative' => false));
JHtml::_('script', 'modules/mod_wt_navbar/js/script.js', array('version' => 'auto', 'relative' => false));


if (count($list)) {
	require JModuleHelper::getLayoutPath('mod_wt_navbar', $params->get('layout', 'default'));
}
