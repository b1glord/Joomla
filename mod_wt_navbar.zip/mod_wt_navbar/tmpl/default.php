<?php
/**
 * @package     WT Navbar - Joomla Extension by WonderTheme.com
 *
 * @copyright   Copyright (C) 2019 WonderTheme.com. All rights reserved.
 * @license     GNU General Public License version 2 or later
 */

defined('_JEXEC') or die;
?>

<style type="text/css">
<?php if ($navBGColor == 'my-color') : ?>
	<?= '#wt-navbar-' . $module->id; ?> {
		background-color: <?= $navBGColorCustom; ?>;
	}
<?php endif; ?>
</style>

<nav id="<?= 'wt-navbar-' . $module->id; ?>" class="wt-navbar navbar <?= $navPlacement . ' ' . $navBGColor . ' ' . $navColorMode . ' ' . $dropdownTransition . ' ' . $dropdownMode . ' ' . $navShadow . ' ' . $navCollapse; ?> <?= $moduleclass_sfx; ?>">

	<?php if ($navContainer) : ?>
		<div class="container">
	<?php endif; ?>

		<?php if ($logo) : ?>
			<a class="navbar-brand" href="<?= $baseURL; ?>"><img src="<?= $baseURL . '/' . $logo ?>" alt="<?= $siteName; ?>" /></a>
		<?php endif; ?>

		<button class="navbar-toggler navbar-toggler-right collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-<?= $module->id; ?>" aria-controls="navbarSupportedContent-<?= $module->id; ?>" aria-expanded="false" aria-label="<?= JTEXT::_('MOD_WT_NAVBAR_TOGGLE_MENU'); ?>">
			<span></span>
			<span></span>
			<span></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarSupportedContent-<?= $module->id; ?>">
			<ul class="navbar-nav <?= $navPosition; ?>">

				<?php
					foreach ($list as $i => &$item) {

            $parentActiveClass = '';

            // user not Guest - Testing Stuff
            // if (!JFactory::getUser()->guest) {
						//
            //   // Detect Parent
            //   if($item->parent == TRUE) {
						//
            //     // get Children list
            //     $children = [];
            //     foreach($list as $x => &$subItem) {
            //       if($subItem->parent_id == $item->id ) {
            //         array_push($children, $subItem);
            //       }
            //     }
						//
            //     foreach ($children as $child) {
            //       if (in_array($child->id, $path)) {
      			// 				$parentActiveClass .= ' active';
      			// 			}
            //     }
						//
            //     die(var_dump($children));
						//
            //     if (in_array($activeId, $item->tree))
            //   	{
            //   		$childs[] = $item->query['id'];
            //   	}
            //     die(var_dump($childs));
            //   }
						//
            // }



						$class = 'nav-item item-' . $item->id;

						if (($item->id == $active_id) OR ($item->type == 'alias' AND $item->params->get('aliasoptions') == $active_id)) {
							$class .= ' current';
						}

						if (in_array($item->id, $path)) {
							$class .= ' active';
						}

						elseif ($item->type == 'alias') {
							$aliasToId = $item->params->get('aliasoptions');

							if (count($path) > 0 && $aliasToId == $path[count($path) - 1]) {
								$class .= ' active';
							}

							elseif (in_array($aliasToId, $path)) {
								$class .= ' alias-parent-active';
							}
						}

						if ($item->type == 'separator') {
							$class .= ' dropdown-divider';
						}

						if ($item->deeper) {
							$class .= ' deeper';
						}

						if ($item->parent) {
							$class .= ' parent dropdown';
						}

						if (!empty($class)) {
							$class = ' class="' . trim($class) . '"';
						}

						echo '<li' . $class . '>';
						$item->anchor_css = 'nav-link ' . $item->anchor_css;

						if ($item->level > $params->get('startLevel')) {
							$item->anchor_css = 'dropdown-item';
							if (count($path) > 0 && $aliasToId == $path[count($path) - 1]) {
								$item->anchor_css .= ' active';
							}
						}

						// The next item is deeper.
						if ($item->deeper) {
							$item->anchor_css .= ' dropdown-toggle';

							foreach ($list as $i => &$newItem) {
								if ($newItem->parent_id == $item->id) {
									if (($newItem->id == $active_id) OR ($newItem->type == 'alias' AND $newItem->params->get('aliasoptions') == $active_id)) {
										$item->anchor_css .= ' active';
									}
								}
							}

							$item->data = 'data-toggle="dropdown"';
						}

						// Render the menu item.
						switch ($item->type) :
							case 'separator':
							case 'url':
							case 'component':
							// case 'heading':
								require JModuleHelper::getLayoutPath('mod_wt_navbar', 'default_' . $item->type);
								break;
							default:
								require JModuleHelper::getLayoutPath('mod_wt_navbar', 'default_url');
						endswitch;

						// The next item is deeper.
						if ($item->deeper) {
							echo '<ul class="dropdown-menu" id="navbar-dropdown-' . $item->id . '">';
						}

						elseif ($item->shallower) {
							// The next item is shallower.
							echo '</li>';
							echo str_repeat('</ul></li>', $item->level_diff);
						}

						else {
							echo '</li>';
						}
					}

				?>

			</ul>

			<?php if ($loadOtherModules && count($modules)) : ?>
				<div id="wt-navbar-modules-<?= $module->id; ?>" class="wt-navbar-modules d-lg-inline-flex ml-lg-0">
					<?php foreach ($modules as $module) : ?>
						<div id="wt-navbar-module-<?= $module->id; ?>" class="wt-navbar-module ml-lg-2 my-2 my-lg-0">
							<?= JModuleHelper::renderModule($module, array('style' => 'none'));?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

		</div>

	<?php if ($navContainer) : ?>
		</div>
	<?php endif; ?>

</nav>
