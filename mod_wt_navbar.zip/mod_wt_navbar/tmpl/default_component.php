<?php
/**
 * @package     WT Navbar - Joomla Extension by WonderTheme.com
 *
 * @copyright   Copyright (C) 2019 WonderTheme.com. All rights reserved.
 * @license     GNU General Public License version 2 or later
 */

defined('_JEXEC') or die;

// Note. It is important to remove spaces between elements.
if ($item->id == $active_id)
{
	$classInner = 'active ';
}
else
{
	$classInner = '';
}
if ($item->anchor_css) {
	$classInner .= $item->anchor_css;
}
$class = 'class="' . $classInner . '" ';
$title = $item->anchor_title ? 'title="' . $item->anchor_title . '" ' : '';

if ($item->menu_image)
{
	$item->params->get('menu_text', 1) ?
	$linktype = '<img src="' . $item->menu_image . '" alt="' . $item->title . '" style="max-width: 26px; margin-right: 5px;" /><span class="image-title">' . $item->title . '</span> ' :
	$linktype = '<img src="' . $item->menu_image . '" alt="' . $item->title . '" style="max-width: 26px; margin-right: 5px;" />';
}
else
{
	$linktype = $item->title;
}

switch ($item->browserNav)
{
	default:
	case 0:
?><a <?php echo $class ?>href="<?php echo $item->flink; ?>" <?php echo $title; ?> <?php echo $item->data; ?>><?php echo $linktype; ?></a><?php
		break;
	case 1:
		// _blank
?><a <?php echo $class; ?>href="<?php echo $item->flink; ?>" target="_blank" <?php echo $title; ?> <?php echo $item->data; ?>><?php echo $linktype; ?></a><?php
		break;
	case 2:
	// Use JavaScript "window.open"
?><a <?php echo $class; ?>href="<?php echo $item->flink; ?>" onclick="window.open(this.href,'targetWindow','toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes');return false;" <?php echo $title; ?> <?php echo $item->data; ?>><?php echo $linktype; ?></a>
<?php
		break;
}
