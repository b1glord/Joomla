<?php
/**
 * @package     WT Navbar - Joomla Extension by WonderTheme.com
 *
 * @copyright   Copyright (C) 2019 WonderTheme.com. All rights reserved.
 * @license     GNU General Public License version 2 or later
 */

defined('_JEXEC') or die;

if ($item->deeper) : ?>
	<a class="nav-link dropdown-toggle" href="#" id="navbar-dropdown-<?= $item->id; ?>" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $item->title; ?></a>
<?php else: ?>
	<a href="#" class=""><?php echo $item->title; ?></a>
<?php endif; ?>
