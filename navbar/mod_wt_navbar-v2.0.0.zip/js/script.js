/**
 * @package     WT Navbar - Joomla Extension by WonderTheme.com
 *
 * @copyright   Copyright (C) 2019 WonderTheme.com. All rights reserved.
 * @license     GNU General Public License version 2 or later
 */

 jQuery(function($) {
   if ("ontouchstart" in document.documentElement) {
     $(document.body).addClass("has-touch");
   } else {
     $(document.body).addClass("no-touch");
   }
 })
