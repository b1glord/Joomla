# Awo Email Login for Joomla

This plugin simply allows the user to login with their registered email address. Install the plugin and publish it. Works alongside Joomla Authentication by allowing the user to log in with either username or email.
