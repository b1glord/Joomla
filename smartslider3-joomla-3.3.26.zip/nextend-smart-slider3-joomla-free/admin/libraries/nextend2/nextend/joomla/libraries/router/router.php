<?php

class N2Router extends N2RouterAbstract
{

}