<?php
N2Loader::import('models.Conflicts', 'smartslider');

class N2SmartsliderConflictsModel extends N2SmartsliderConflictsModelAbstract {

    public function __construct() {
        parent::__construct();
    }

}